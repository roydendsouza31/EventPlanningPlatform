# Event Planning Platform

## Group Members
- Royden Dsouza
- Rahul Bandekar
- Alishka Fernandes
- Allieah Ferrao
- Riddhi Shinde
